package org.example.enums;

public enum Gender {
    MALE, FEMALE
}
