package org.example.enums;

public enum Deparment {
    MATERNITY, PEDIATRICS, ORTHOPEDIC
}
