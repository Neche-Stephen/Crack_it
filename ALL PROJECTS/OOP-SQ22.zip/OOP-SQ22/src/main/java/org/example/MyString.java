package org.example;

public class MyString {

    private String  original;

    public MyString(String original) {
        this.original = original;
    }
}
