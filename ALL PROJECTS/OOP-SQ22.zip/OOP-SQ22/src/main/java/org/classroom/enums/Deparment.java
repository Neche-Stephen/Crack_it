package org.classroom.enums;

public enum Deparment {
    JAVA, NODE, DOTNET
}
