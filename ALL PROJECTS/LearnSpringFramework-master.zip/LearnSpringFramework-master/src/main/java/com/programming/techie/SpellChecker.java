package com.programming.techie;

interface SpellChecker {
    void checkSpelling(String emailMessage);
}
